import VerifyPage from '../../pages/verify';

export default function VerifyPageExample() {
  return <VerifyPage />;
}
